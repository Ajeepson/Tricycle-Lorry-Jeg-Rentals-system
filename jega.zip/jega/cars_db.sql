-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2023 at 09:07 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cars_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `pass` varchar(65) NOT NULL,
  `secrete` varchar(100) NOT NULL,
  `answer` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `pass`, `secrete`, `answer`) VALUES
(1, 'admin', '12345', 'my favorate programming language', 'php');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(6) UNSIGNED NOT NULL,
  `car_name` varchar(25) NOT NULL,
  `price` varchar(25) NOT NULL,
  `description` longtext DEFAULT NULL,
  `quantity` varchar(25) NOT NULL,
  `category` varchar(45) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `car_name`, `price`, `description`, `quantity`, `category`, `photo`) VALUES
(1, 'MALA RENTAL SERVICES', '4500', '+2348066112006', 'Cartons of fish', 'sabon fegi', '../images/slide-1.JPEG'),
(2, 'Yusuf Dabo Alimarami rent', '4500', '0901726347565', 'rice', 'ALIMARAMI HOUSING ESTATE', '../images/slide-13.JPEG'),
(3, 'Yusuf Dabo Alimarami rent', '4500', '0901726347565', 'food stuff', 'ALIMARAMI HOUSING ESTATE', '../images/slide-11.JPEG'),
(4, 'IBRAHIM SALEH RENTALS', '4000', '080366277482', 'farm produce', ' 3 bedroom gujuba road', '../images/slide-5.JPEG'),
(32, 'ADAMU SAIDU MULTI-PURPOSE', '3950', '08115644667', 'cement', 'SABON FEGI', '../images/slide-2.JPEG'),
(33, 'HAJIYA MAIMUNA MAI JEGA', '4000', '09034558832', 'services', ' BUHARI ESTATE', '../images/slide-25.JPEG'),
(34, 'JIBRIN FIKA', '4500', NULL, 'packaged water(pure water', ' ABARI ', '../images/slide-24.JPEG');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `bussiness_name` varchar(45) NOT NULL,
  `phone_no` varchar(45) NOT NULL,
  `content` varchar(45) NOT NULL,
  `quantity` int(11) NOT NULL,
  `addressn` varchar(45) NOT NULL,
  `price` int(11) NOT NULL,
  `message` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `bussiness_name`, `phone_no`, `content`, `quantity`, `addressn`, `price`, `message`) VALUES
(1, 'MALA RENTAL SERVICES', '+2348066112006', '12', 0, 'sabon fegi', 4500, 'within damaturu metroplis and good road'),
(2, 'Yusuf Dabo Alimarami rental service', '0901726347565', '4', 0, 'ALIMARAMI HOUSING ESTATE', 4500, 'it should be within damaturu metropolis '),
(4, 'IBRAHIM SALEH RENTALS', '080366277482', '14', 0, ' 3 bedroom gujuba road', 4000, 'The location should be within damatur me'),
(5, 'AMINU A BAPA', '08034524433', '12', 0, ' WAZIRI IBRAHIM ', 4500, 'WITHIN DAMATURU METROPOLISE'),
(7, 'ADAMU SAIDU MULTI-PURPOSE RENTAL SERVICE', '08115644667', '40', 0, ' NYAYA LINE C', 3950, 'DAMATURU'),
(9, 'ADAMU SAIDU MULTI-PURPOSE RENTAL SERVICE', '08115644667', '40', 0, ' NYAYA', 3950, 'DTR'),
(11, 'HAJIYA MAIMUNA MAI JEGA', '09034558832', '23', 0, ' BUHARI ESTATE', 4000, 'DTR'),
(12, 'JIBRIN FIKA', '08064288829', '34', 0, ' ABARI ', 4500, 'DTR');

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(65) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `tract_number` varchar(25) NOT NULL,
  `complaint` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_car`
--

CREATE TABLE `order_car` (
  `id` int(6) UNSIGNED NOT NULL,
  `car_name` varchar(65) NOT NULL,
  `price` varchar(25) NOT NULL,
  `quantity` varchar(65) NOT NULL,
  `total` varchar(65) NOT NULL,
  `card_number` varchar(65) NOT NULL,
  `card_name` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `tract_number` varchar(25) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_car`
--

INSERT INTO `order_car` (`id`, `car_name`, `price`, `quantity`, `total`, `card_number`, `card_name`, `username`, `tract_number`, `status`) VALUES
(1, 'MALA RENTAL SERVICES', '4500', '0', '54000', '+2348066112006', 'within damaturu metroplis', '', '12', ''),
(2, 'Yusuf Dabo Alimarami rental service', '4500', '0', '54000', '0901726347565', 'it should be within damat', '', '12', ''),
(4, 'IBRAHIM SALEH RENTALS', '4000', '0', '48000', '080366277482', 'The location should be wi', '', '12', ''),
(5, 'AMINU A BAPA', '4500', '0', '54000', '08034524433', 'WITHIN DAMATURU METROPOLI', '', '12', ''),
(7, 'ADAMU SAIDU MULTI-PURPOSE RENTAL SERVICE', '3950', '0', '47400', '08115644667', 'DAMATURU', '', '12', ''),
(9, 'ADAMU SAIDU MULTI-PURPOSE RENTAL SERVICE', '3950', '0', '47400', '08115644667', 'DTR', '', '12', ''),
(11, 'HAJIYA MAIMUNA MAI JEGA', '4000', '0', '48000', '09034558832', 'DTR', '', '12', ''),
(12, 'JIBRIN FIKA', '4500', '0', '54000', '08064288829', 'DTR', '', '12', ''),
(0, 'HAJIYA MAIMUNA MAI JEGA', '4000', '', '0', '460354003', 'alkasim', 'sasuke', '20455733', '');

-- --------------------------------------------------------

--
-- Table structure for table `pin`
--

CREATE TABLE `pin` (
  `id` int(6) UNSIGNED NOT NULL,
  `card_name` varchar(65) NOT NULL,
  `card_number` varchar(60) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `card_pin` varchar(65) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pin`
--

INSERT INTO `pin` (`id`, `card_name`, `card_number`, `amount`, `card_pin`) VALUES
(2, 'Kasim Abubakar Jajere', '460354003', '10000', '12345'),
(3, 'Babba Sodangi', '399162811', '9000', '12345'),
(5, 'Aliyu Isa', '1330585708', '2000', '12345'),
(6, 'Aliyu Isa', '1358943652', '2000', '12345'),
(7, 'Aliyu Isa', '10456734', '2000', '12345'),
(8, 'Aliyu Adamu', '322824432', '1000', '12345'),
(9, '0987654321', '1428717207', '10000', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `id` int(6) UNSIGNED NOT NULL,
  `shipping_address` longtext DEFAULT NULL,
  `name` varchar(65) NOT NULL,
  `email` varchar(65) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `tract_number` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shipping_status`
--

CREATE TABLE `shipping_status` (
  `id` int(6) UNSIGNED NOT NULL,
  `tract_number` varchar(25) NOT NULL,
  `status` longtext DEFAULT NULL,
  `username` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping_status`
--

INSERT INTO `shipping_status` (`id`, `tract_number`, `status`, `username`) VALUES
(10, '9420436', 'We receive your order we are going to process your order shortly thanks for shopping with us', 'baba'),
(11, '1946682', 'We receive your order we are going to process your order shortly thanks for shopping with us', 'baba'),
(12, '1395356', 'We ship your car you will recieve it within 5 working days expect your car on 28/2/2015 Thanks for doing business with us', 'alkasima'),
(13, '13909028', ' ', ''),
(14, '21163066', ' We confirm your request your order is in progress we ship your details to our logistic company call them and confirm your shipping status', 'aliyu_adamu'),
(15, '20455733', 'We receive your order we are going to process your order shortly thanks for shopping with us', 'sasuke');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(6) UNSIGNED NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `sex` varchar(8) NOT NULL,
  `birth` varchar(12) NOT NULL,
  `state` varchar(20) NOT NULL,
  `l_g_a` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `shipping_address` longtext DEFAULT NULL,
  `photo` varchar(100) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `first_name`, `last_name`, `sex`, `birth`, `state`, `l_g_a`, `email`, `phone`, `shipping_address`, `photo`, `username`, `password`) VALUES
(4, 'baba', 'sodangi', 'Male', '09-05-2005', 'yobe', 'potiskum', 'babasodangi@gmail.com', '08061557821', 'no.22 muhammad idris way potiskum yobe state ', 'Desert.jpg', 'baba', '12345'),
(9, 'Musa', 'Habu', 'Male', '1997-02-03', 'Borno', 'Bama', 'musa@gmail.com', '08034422344', 'Emir palace ', 'Desert.jpg', 'musa', '12345'),
(10, 'Kasim', 'Abubakar Jajere', 'Male', '1/1/1991', 'Yobe', 'Fune', 'alkasima@gmail.com', '08068262120', 'Old Army Barrack Potiskum ', 'images/b.jpg', 'alkasima', '12345'),
(11, 'Aliyu', 'Adamu', 'Male', '2006-01-31', 'Yobe', 'Potiskum', 'aliyu@ymail.com', '08034222222', ' xxxxxx', 'images/(Nagane).jpg', 'aliyu_adamu', '12345'),
(12, 'AJIBADE', 'BASHIR', 'Male', '', 'Yobe', 'dtr', 'bashirson09@gmail.com', '08066112006', 'sabon fegi', 'images/th (1).jpg', 'sasuke', 'sasuke');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_car`
--
ALTER TABLE `order_car`
  ADD KEY `id` (`id`);

--
-- Indexes for table `pin`
--
ALTER TABLE `pin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping_status`
--
ALTER TABLE `shipping_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pin`
--
ALTER TABLE `pin`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shipping_status`
--
ALTER TABLE `shipping_status`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
