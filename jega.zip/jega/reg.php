<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based on Jega hiring Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <div id="upper_link"><p><a href="login.php">Login</a> | <a href="reg.php">Sign Up</a> | <a href="admin">Admin</a><span>07080174336</span></p></div>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="index.html" class="home"><img src="images/home.jpg" alt=""></a></li>
        
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">New Customer</h2>
        <div class="box-6">
        
<div align="center">
<form action="reg_script.php"   enctype="multipart/form-data" method="post" >

<table border="1" width="80%">
<tr>
<td><strong>First Name: </strong></td>
<td><input type="text" name="first_name" required></td>
</tr>
<tr>
<td><strong>Last Name: </strong></td>
<td><input type="text" name="last_name" required></td>
</tr>
<tr>
<td><strong>Sex: </strong></td>
<td><select name="sex"> <option>Male</option> <option> Female</option> </select> </td>
</tr>
<tr>
<td><strong>Birth: </strong></td>
<td><input type="date" name="birth"></td> 
</tr>
<tr>
<td><strong>State: </strong> </td>
<td><input type="text" name="state" required> </td>
</tr>
<tr>
<td><strong>L.G.A: </strong> </td>
<td><input type="text" name="l_g_a"> </td>
</tr>
<tr>
<td><strong>Email: </strong> </td>
<td><input type="text" name="email" required> </td>
</tr>
<tr>
<td><strong>Phone: </strong> </td>
<td><input type="text" maxlength="11" name="phone"> </td>
</tr>
<tr>
<td><strong>Address: </strong> </td>
<td><textarea name="address"> </textarea>
</tr>
<tr>
<td><strong>Photo: </strong> </td>
<td><input type="file" name="photo"> </td>
</tr>
<tr>
<td><strong>Username: </strong></td>
<td><input type="text" name="username" required> </td>
</tr>
<tr>
<td><strong>Password: </strong></td>
<td><input type="password" name="password" required>
</tr>
<tr>
<td colspan="2"><center><input type="submit" value="Register"> <input type="reset" value="Clear"></td>

</table>
<p>&nbsp;</p>
</div>
        
        </div>
      </div>
    </div>
  </section>
  <footer>web based on Jega hiring system &copy; 2022| <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>