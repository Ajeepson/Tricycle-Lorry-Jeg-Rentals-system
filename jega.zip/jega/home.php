<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based on Jega hiring System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['username']; ?><span>07080174336</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="images/home.jpg" alt=""></a></li>
        <li><a href="order_status.php">Order Status</a></li>
        <li><a href="categories.php">Categories</a></li>
        <li><a href="check_card.php">Check Card Balance</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">WELCOME</h2>
        <div class="box-6">
        <div align="center">
        <p>We are welcoming you to our website on Jega hiring as much  as you like with your card</p>
        		<?php
require_once('db_function.php');



$query=mysqli_query($conn, "select * from cars");

while($row=mysqli_fetch_array($query)) {

?>
      <p>      
      <div style="float: left; margin-left: 20px;">



</font>

<a href="order.php?id=<?php echo $row['id']; ?>"> <img src="./admin/<?php echo $row['photo']; ?>" width="150" height="150"></a>

<p> <?php echo $row['car_name']; ?></p>
<p> <font color="#FF0000">Price: <?php echo "#".$row['price']; ?> </font></p>

</div>


<?php
}


?>  
 

</p>










          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
  <footer>web based on Jega hiring system &copy; 2022| <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>