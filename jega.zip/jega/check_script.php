<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Jega Hiring Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<style>

table {
	width:600px;
	border-collapse:collapse;
	}
	th{background-color:#000000;
	color:#FFFFFF;
	
	}
	input#image-button {
	background:#ccc url('./images/continue.png')
	no-repeat top left;
	padding-left: 193px;
	height: 53px;
	}
	
#cat_link {
			
}

#cat_link a {
		
		font:Verdana, Geneva, sans-serif;
		font-size:14px;	
}

#cat_link a:hover {
	background:#2A1F00;
	color:#fff;	
}
</style>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['username']; ?><span>07013277741</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="images/home.jpg" alt=""></a></li>
        <li><a href="order_status.php">Order Status</a></li>
        <li><a href="categories.php">Categories</a></li>
        <li class="current"><a href="check_card.php">Check Card Balance</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">AVAILABLE CARD BALANCE</h2>
        <div class="box-6">
        <div align="center">
      
      <p>
   
	<center>				
<?php


include('db_function.php');

$card_number = $_POST['card_number'];
$card_pin = $_POST['card_pin'];

$query = "SELECT * from pin WHERE card_number='$card_number' And card_pin='$card_pin'";

$result = mysqli_query($conn,$query) or die(mysqli_error());

$count = mysqli_num_rows($result);

if($count == 1) {

?>
<table border="1" width="600">
<tr>
<th colspan="4">CARD BALANCE</th>
<tr>
<td><strong>Card Name</strong><td> <strong> Card Number </strong> </td> <td> <strong> Amount </strong> </td>
</tr>
<?php


$query = "SELECT * from pin where card_number='$card_number'";

$result = mysqli_query($conn,$query) or die(mysqli_error());

$count = mysqli_num_rows($result);


while ($row=(mysqli_fetch_array($result))) {


?> <tr>
<td> <?php echo $row['card_name']; ?> </td>
<td> <?php echo $row['card_number']; ?> </td>
<td> <?php echo "#".$row['amount']; ?> </td>


<?php
}





} else {

echo "Wrong card number or card pin";
	echo "<br>";
	?>

    <a href="check_card.php">Try Again </a>
<?php
}
?>
</p>
</table>

</p>










          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
<footer>web based on jega Hiring system &copy; 2023 | <a href="#">By Aliyu Adamu Danjuma</a> | Supervised by: <a href="#">Mr. David Oladipo Tayo</a></footer>
</div>
</body>
</html>