<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Administrator</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="../css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="../js/jquery-1.7.min.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="../index.html"><img src="../images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['admin_username']; ?><span>07080174336</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="../images/home.jpg" alt=""></a></li>
        <li><a href="add_cars.php">Add jega</a></li>
        <li ><a href="order_request.php">Order Request</a></li>
        <li><a href="available.php">Available jega</a></li>
        <li><a href="ordered_cars.php">Ordered jega</a></li>
        <li class="current"><a href="generate_card.php">Generate Card</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">NEW Jega REG</h2>
        <div class="box-6">
        <div align="center">
                
        <p>

<p>


<center>

<form action="generate_card_script.php" method="post">

<table border="1" width="600">
<tr>
<th colspan="2">  <marquee behavior="alternate">GENERATE SHOPPING CARD </marquee> </th>
</tr>

<tr>
<td><strong>Card Name: </strong></td>
<td><input type="text" name="card_name"> </td>
<tr>
<td><strong>Amount </strong> </td>
<td><input type="text" name="amount"> </td>
</tr>
<tr>
<td><strong>Card Pin </strong> </td>
<td><input type="text" name="card_pin"> </td>
</tr>


<td colspan="2"> <center><input type="submit" value="Generate"> <input type="reset" value="Reset"></td>


</table>
</center>
</p>




          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
<footer>web based on Jega hiring system &copy; 2022 | <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>