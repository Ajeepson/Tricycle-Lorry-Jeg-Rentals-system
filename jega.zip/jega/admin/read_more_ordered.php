<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Administrator</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="../css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="../js/jquery-1.7.min.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="../index.html"><img src="../images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['admin_username']; ?><span>07080174336</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="../images/home.jpg" alt=""></a></li>
        <li><a href="add_cars.php">Add Jega</a></li>
        <li ><a href="order_request.php">Order Request</a></li>
        <li><a href="available.php">Available Jega</a></li>
        <li class="current" ><a href="ordered_cars.php">Ordered Jega</a></li>
        <li><a href="generate_card.php">Generate Card</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">CONFIRM ORDERED</h2>
        <div class="box-6">
        <div align="center">
     
        
      <p>
<center>

<table border="1" width="600">

<?php

include('db_function.php');

$id = $_GET['id'];

$query = "SELECT * from order_car where id='$id'";

$result = mysqli_query($conn,$query) or die(mysqli_error());

$count = mysqli_num_rows($result);



while ($row=(mysqli_fetch_array($result))) {


$car_name = $row['car_name'];
$price = $row['price'];
$quantity = $row['quantity'];
$total = $row['total'];
$username = $row['username'];

$_SESSION['tract_number'] = $row['tract_number'];


?>

<th colspan="2"> <center> JEGA DETAILS </center> </th>
<tr>
<td><strong>Jega Name</strong></td>  <td><?php echo $row['car_name']; ?></td>
</tr>
<tr>
<td>Quanity</td> <td> <?php echo $row['quantity']; ?> </td>
</tr>
<tr>
<td><strong> Total Amount </td> <td> <?php echo "#".$row['total']; ?> </td>
</tr>
<tr>
<td><strong> Card Number </strong> </td> <td> <?php echo $row['card_number']; ?> </td>
</tr>
<tr>
<td><strong>Card Name </strong> </td> <td> <?php echo $row['card_name']; ?> </td>
</tr>
<tr>
<td><strong> Track Number </td> <td> <?php echo $row['tract_number']; ?> </td>
</tr>
<tr>
<th colspan="2"> <center> Hiring DETAILS  </center> </th>
</tr>
<tr>

<?php

$username = $row['username'];

$query = "SELECT * from user where username='$username'";

$result = mysqli_query($conn,$query) or die(mysqli_error());

$count = mysqli_num_rows($result);



while ($row=(mysqli_fetch_array($result))) {


$customer_name = $row['first_name'] ." ". $row['last_name'];
$address = $row['shipping_address'];
$phone = $row['phone'];
$email = $row['email'];
$state = $row['state'];
$l_g_a = $row['l_g_a'];

}
?>
<td> <strong> Customer Name </strong> </td> <td> <?php echo $customer_name; ?> </td>
</tr>
<tr>
<td> <strong> Hiring Address </strong> </td> <td> <?php echo $address; ?> </td>
</tr>
<tr>
<td> <strong> Phone </strong> </td> <td> <?php echo $phone; ?> </td>
</tr>
<tr>
<td> <strong> Email </strong> </td> <td> <?php echo $email; ?> </td>
</tr>
<tr>
<td> <strong> State </strong> </td> <td> <?php echo $state; ?> </td>
</tr>
<tr>
<td> <strong> L.G.A </strong> </td> <td> <?php echo $l_g_a; ?> </td>
</tr>
<tr>
<td>..</td>
</tr>
<tr>
<td>..</td>
</tr>
<tr>


<tr>
<td colspan="6" bgcolor="black"> <font color="white"><marquee scrollamount="2"> Customer and Jega details once you confirmed this order customer may be able to see his shipping status</marquee></font></td>

<?php
}
$conn->close();
?>
</table>
</center>
</p>


          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
<footer>web based on Jega hiring  system &copy; 2022| <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>