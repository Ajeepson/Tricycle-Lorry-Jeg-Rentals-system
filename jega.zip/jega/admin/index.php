<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based Auto Mobile Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="../css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="../js/jquery-1.7.min.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="../index.html"><img src="../images/logo.png" alt=""></a></h1>
      <div id="upper_link"><p><a href="../login.php">Login</a> | <a href="../reg.php">Sign Up</a> | <a href="../admin">Admin</a><span>07080174336</span></p></div>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="../index.html" class="home"><img src="../images/home.jpg" alt=""></a></li>
        
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">ADMINISTRATOR</h2>
        <div class="box-6">
        <div align="center">


	<center>				
<table border="1" width="800px">
<form action="login_script.php" method="post">
<th colspan="2"><strong><center><blink>login</blink></strong><th>
<tr>
<td><strong>username</strong></td>
<td><input type="text" name="username"></td>
</tr>
<tr>
<td><strong>password</strong></td>
<td><input type="password" name="password"></td>
<tr>
<th colspan="2"><center><input type="submit" value="login"> 
</tr>
</form>
</table>
</center>

          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
<footer>web based on Jega hiring system &copy; 2022 | <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>