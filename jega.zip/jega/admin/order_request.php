<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Administrator</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="../css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="../css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="../js/jquery-1.7.min.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="../index.html"><img src="../images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['admin_username']; ?><span>07080174336</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="../images/home.jpg" alt=""></a></li>
        <li><a href="add_cars.php">Add jega</a></li>
        <li class="current" ><a href="order_request.php">Order Request</a></li>
        <li><a href="available.php">Available jega</a></li>
        <li><a href="ordered_cars.php">Ordered jega</a></li>
        <li><a href="generate_card.php">Generate Card</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">ORDER REQUEST</h2>
        <div class="box-6">
        <div align="center">
        <p>Use this form below to add new Jega to your database</p>
        
        <p>
<p>
<center>

<table border="1" width="600">
<tr>
<th colspan="6"> <center> NOTIFICATION </center></th>
<tr>
<td><strong>Username</strong><td> <strong> Jega Name</strong> </td>  <td> <strong> Quantity </strong> </td> <td> <strong> Total</td>
<td> .</td>
</tr>
<?php

include('db_function.php');

$query = "SELECT * from order_car where status=''";

$result = mysqli_query($conn,$query) or die(mysqli_error());

$count = mysqli_num_rows($result);



while ($row=(mysqli_fetch_array($result))) {


$car_name = $row['car_name'];
$price = $row['price'];
$quantity = $row['quantity'];
$total = $row['total'];
$username = $row['username'];


?>


<tr>
<td><?php echo $row['username']; ?></td>  <td> <?php echo $row['car_name']; ?> </td> <td> <?php echo $row['quantity']; ?> </td>

<td> <font color="red"> <?php echo "#".$row['total']; ?> </font> </td>
 <td>

<a href="read_more.php?id=<?php echo $row['id']; ?> "> Read More </a></td>


<tr>
</tr>
<?php
}
?>
<td colspan="6" bgcolor="black"> <font color="white"> <?php echo $count; ?> Product waiting for confirmation </font></td>


<?php

$conn->close();
?>
</table>
</center>
</p>



          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
<footer>web based Jega hiring system &copy; 2022 | <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>