<?php
$conn = mysqli_connect('localhost','root','','cars_db(1)');
if(!$conn){
die($conn).connect_error();
}
?>