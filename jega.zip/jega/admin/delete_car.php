<?php 


include('db_function.php');


$id = $_GET['id'];


$query = " delete from cars where id='$id'";


if($conn->query($query) === true) {


?> 

<script>
window.location ="available.php";

</script>

<?php
 

}
 else  {

			echo "Error deleting record:".$conn->error;
}
$conn->close();




?>
