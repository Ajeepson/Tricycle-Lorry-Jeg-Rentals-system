<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based on Jega Hiring Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<style>

table {
	width:600px;
	border-collapse:collapse;
	}
	th{background-color:#000000;
	color:#FFFFFF;
	
	}
	input#image-button {
	background:#ccc url('./images/continue.png')
	no-repeat top left;
	padding-left: 193px;
	height: 53px;
	}
</style>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['username']; ?><span>07080174336</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="images/home.jpg" alt=""></a></li>
        <li><a href="order_status.php">Order Status</a></li>
        <li><a href="categories.php">Categories</a></li>
        <li><a href="check_card.php">Check Card Balance</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">HiringS DETAILS</h2>
        <div class="box-6">
        <div align="center">
      
      <p>
      			<?php
require_once('db_function.php');



$id = $_SESSION['id'];


$query=mysqli_query($conn, "select * from cars where id='$id'");

while($row=mysqli_fetch_array($query)) {

$car_name = $row['car_name'];
$price = $row['price'];

$_SESSION['car_name'] = $car_name;
$_SESSION['price'] = $price;
}

$card_number = $_POST['card_number'];
$pin = $_POST['pin'];
$quantity = $_POST['quantity'];

$_SESSION['card_number'] = $card_number;
$_SESSION['card_name'] = $_POST['card_name'];

$_SESSION['quantity'] = $quantity;

$total = $price * $quantity;

$_SESSION['total'] = $total;

$query = "SELECT * from pin WHERE card_number='$card_number' And card_pin='$pin'";

$result = mysqli_query($conn,$query) or die(mysqli_error());

$count = mysqli_num_rows($result);

if($count == 1) {

$query=mysqli_query($conn, "select * from pin where card_number ='$card_number' and card_pin='$pin'");

while($row=mysqli_fetch_array($query)) {

$amount = $row['amount'];

}

if( $total > $amount) {

?> <font color="red"> <?php echo "Insuffient amount";

?>
<script>


alert("Insuffient amount");
window.location="order_script.php";
</script>
<?php
}



} else {

?>




<h1> <font color="red">Wrong Card number or Pin</h1>
<br>

<center>
<h1> <a href="order_script.php">Try Again</a> </h1>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<?php
echo "<br>";
echo "<br>";
echo "<br>";
exit;


}








$username = $_SESSION['username'];




$query=mysqli_query($conn, "select * from user where username='$username'");

while($row=mysqli_fetch_array($query)) {

$name = $row['first_name'] ." ". $row['last_name'];
$address = $row['shipping_address'];
$gender = $row['sex'];
$phone = $row['phone'];
$email = $row['email'];
$state = $row['state'];
$l_g_a = $row['l_g_a'];

 

}



$id = $_SESSION['id'];


$query=mysqli_query($conn, "select * from cars where id='$id'");

while($row=mysqli_fetch_array($query)) {

$product_name = $row['car_name'];
$price = $row['price'];





?>

      <p>      

      <div style="float: left; margin-left: 20px;">



</font>

 
 <center>				
<table border="1" width="100px">
<form action="login_script.php" method="post">
<th colspan="2"><strong>ORDER INFORMATION</strong><th>
<tr>
<td><strong>Product Name: </strong></td>
<td><?php echo $car_name; ?></td>
</tr>
<tr>
<td><strong>Price: </strong></td>
<td>#<?php echo $price; ?></td>
</tr>
<tr>
<td><strong> Quantity: </strong></td>
<td> <?php echo $quantity; ?> </td>
</tr>
<tr>
<td><strong>Total: </strong></td>
<td> <font color="red"> <?php echo "#".$total; ?> </font></td>
</tr>
<tr>
<th colspan="2"><strong>Hiring INFORMATION</strong><th>
</tr>
<tr>
<td><strong>Name: </strong></td>
<td> <?php echo $name; ?> </td>
</tr>
<tr>
<td><strong>Hiring Address</strong></td>
<td> <?php echo $address; ?> </td>
</tr>
<tr>
<td><strong>Gender: </strong> </td>
<td> <?php echo $gender; ?> </td>
</tr>
<tr>
<td><strong>Phone: </strong> </td>
<td> <?php echo $phone; ?> </td>
</tr>
<tr>
<td><strong>E-mail: </strong> </td>
<td><?php echo $email; ?> </td>
</tr>
<tr>
<td><strong>State: </strong> </td>
<td> <?php echo $state; ?> </td>
</tr>
<tr>
<td><strong>L.G.A: </strong> </td>
<td> <?php echo $l_g_a; ?> </td>




</tr>
</form>
</table>
</center>
<br />
<center>  <a href="order_script3.php?id=<?php echo $row['id']; ?>">  <img src="./images/confirm.png">  </a>     </center>

</div>


<?php
}


?>  



</p>










          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
  <footer>web based on Jega hiring system &copy; 2022| <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>