<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based on Jega hiring Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<style>

table {
	width:600px;
	border-collapse:collapse;
	}
	th{background-color:#000000;
	color:#FFFFFF;
	
	}
	input#image-button {
	background:#ccc url('./images/continue.png')
	no-repeat top left;
	padding-left: 193px;
	height: 53px;
	}
</style>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['username']; ?><span>07080174336</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="images/home.jpg" alt=""></a></li>
        <li class="current"><a href="order_status.php">Order Status</a></li>
        <li><a href="categories.php">Categories</a></li>
        <li><a href="check_card.php">Check Card Balance</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">ORDER STATUS</h2>
        <div class="box-6">
        <div align="center">
      
      <p>
      <table border="1">
<tr>
<th colspan="4">Hiring STATUS</th>
<tr>
<td><strong>Status</strong><td> <strong> Tract Number </strong> </td> 
</tr>

<?php

include('db_function.php');

$username = $_SESSION['username'];

$query = "SELECT * from shipping_status where username='$username'";

$result = mysqli_query($conn,$query) or die(mysqli_error());

$count = mysqli_num_rows($result);


while ($row=(mysqli_fetch_array($result))) {


$status = $row['status'];
$tract_number = $row['tract_number'];

?>
<tr>
<td><?php echo $row['status']; ?></td>  <td> <?php echo $row['tract_number']; ?> </td>

<?php
}

mysqli_close($conn);
?>

</p>
</table>


</p>










          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
  <footer>web based on Jega hiring system &copy; 2022| <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>