<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based on jega hiring Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['username']; ?><span>07080174336</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="images/home.jpg" alt=""></a></li>
        <li><a href="order_status.php">Order Status</a></li>
        <li><a href="categories.php">Categories</a></li>
        <li><a href="check_card.php">Check Card Balance</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">ORDER PAGE</h2>
        <div class="box-6">
        <div align="center">
      
      
      		<?php
require_once('db_function.php');

$id = $_GET['id'];

$_SESSION['id'] = $id;

$query=mysqli_query($conn, "select * from cars where id='$id'");

while($row=mysqli_fetch_array($query)) {

?>

      <p>      

      <div style="float: left; margin-left: 20px;">



</font>

 <img src="./admin/<?php echo $row['photo']; ?>" width="150" height="150"></a>
<?php
$_SESSION['name'] = $row['car_name'];
$_SESSION['id'] = $row['id'];
$_SESSION['price']= $row['price'];
$_SESSION['category'] = $row['category'];
?>
<p> Price:: <font color="#FF0000"> <?php echo "#".$row['price']; ?> </font></p>
<p> Category:: <font color="#FF0000"> <?php echo "#".$row['category']; ?> </font></p>
<p> Description:: <?php echo $row['description']; ?> </p>
<br />
<center>  <a href="order_script.php?id=<?php echo $row['id']; ?>">  <img src="./images/buy.png" width="110" height="53">  </a>     </center>

<p style="float:right"><a href="home.php"> &laquo;Back</a></p>
</div>


<?php
}


?>  


      
      
      
      

</p>










          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
  <footer>web based on Jega hiring system &copy; 2022| <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>