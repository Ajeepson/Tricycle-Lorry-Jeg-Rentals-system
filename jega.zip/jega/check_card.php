<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based Auto Mobile Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<style>

table {
	width:600px;
	border-collapse:collapse;
	}
	th{background-color:#000000;
	color:#FFFFFF;
	
	}
	input#image-button {
	background:#ccc url('./images/continue.png')
	no-repeat top left;
	padding-left: 193px;
	height: 53px;
	}
	
#cat_link {
			
}

#cat_link a {
		
		font:Verdana, Geneva, sans-serif;
		font-size:14px;	
}

#cat_link a:hover {
	background:#2A1F00;
	color:#fff;	
}
</style>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <p>Hello: <?php echo $_SESSION['username']; ?><span>08161225977</span></p>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="home.php" class="home"><img src="images/home.jpg" alt=""></a></li>
        <li><a href="order_status.php">Order Status</a></li>
        
        <li><a href="categories.php">Categories</a></li>
        <li class="current"><a href="check_card.php">Check Card Balance</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">CHECK CARD</h2>
        <div class="box-6">
        <div align="center">
      
      <p>
   
   <center>				
<table border="1" width="600">
<form action="check_script.php" method="post">
<th colspan="2"><strong>Card Details</strong><th>
<tr>
<td><strong>Card Number</strong></td>
<td><input type="text" name="card_number"></td>
</tr>
<tr>
<td><strong>Card Pin</strong></td>
<td><input type="password" name="card_pin"></td>
<tr>
<th colspan="3"><center><input type="submit" value="Check"> </tr>
</form>
</table>
</center>



</p>










          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
<footer>web based auto mobile system &copy; 2015 | <a href="#">By Aliyu Adamu Danjuma</a> | Supervised by: <a href="#">Mr. David Oladipo Tayo</a></footer>
</div>
</body>
</html>