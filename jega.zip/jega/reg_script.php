<!DOCTYPE html>
<html lang="en">
<head>
<title>Web based on Jega Hiring Information System</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.7.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<!--[if lt IE 9]>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/html5.js"></script>
<link rel="stylesheet" type="text/css" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<div class="bg">
  <header>
    <div class="main wrap">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
      <div id="upper_link"><p><a href="login.php">Login</a> | <a href="reg.php">Sign Up</a> | <a href="admin">Admin</a><span>07080174336</span></p></div>
    </div>
    <nav>
      <ul class="menu">
        <li><a href="index.html" class="home"><img src="images/home.jpg" alt=""></a></li>
        
      </ul>
      <div class="clear"></div>
    </nav>
  </header>
  <section id="content">
    <div class="sub-page">
      <div class="sub-page-left">
        <h2 class="p4">New Customer</h2>
        <div class="box-6">
        <div align="center">


<?php
include('db_function.php');

$uploadir = 'images/';

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$sex = $_POST['sex'];
$birth = $_POST['birth'];
$state = $_POST['state'];
$l_g_a = $_POST['l_g_a'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$username = $_POST['username'];
$password = $_POST['password'];


$fileName= $_FILES['photo']['name'];
$tmpName = $_FILES['photo']['tmp_name'];
$filesize = $_FILES['photo']['size'];
$fietype = $_FILES['photo']['type'];

$filepath = $uploadir . $fileName;

$result= move_uploaded_file($tmpName , $filepath);

$sql = "INSERT INTO user(first_name,last_name,sex,birth,state,l_g_a,email,phone,shipping_address,username,password,photo)
VALUES('$first_name','$last_name','$sex','$birth','$state','$l_g_a','$email','$phone','$address','$username','$password','$filepath')";
if($conn->query($sql) == TRUE) {

	echo "You haved registered Successfully";
	echo "<br>";
	echo '<a href="login.php">Login Here</a>';
	}else {
		echo "Error While registering:".$conn->error;
	}
$conn->close();





?>					
</div>

          
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div>
      </div>
    </div>
  </section>
  <footer>web based on Jega hiring system &copy; 2022| <a href="#">By Umar Musa</a> | Supervised by: <a href="#">Mallam. Yau Nuhu</a></footer>
</div>
</body>
</html>