<?php


$conn = new mysqli("localhost","root");

$conn->select_db('cars_db(1)');


//check connection
if($conn->connect_error) {
	die("Connection failed:".$conn->connect_error);

}
?>